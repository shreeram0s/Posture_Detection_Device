package com.example.posture_device

import android.content.Context
import android.hardware.Sensor

import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.widget.Button
import android.hardware.SensorManager
import android.os.Build
import android.os.Bundle
import android.os.VibrationEffect
import android.os.Vibrator
import android.util.Log
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import android.os.Handler
import android.os.Looper
import android.content.Intent
import android.graphics.Color

class MainActivity : AppCompatActivity(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private var accelerometer: Sensor? = null
    private lateinit var postureText: TextView
    private lateinit var vibrator: Vibrator
    private lateinit var coordinatesText: TextView
    private var badPostureCount = 0 // Track the number of bad posture occurrences
    private lateinit var mockSensor: MockSensor
    private lateinit var traceStatusButton: Button

    companion object {
        private const val POSTURE_THRESHOLD = 5 // Threshold for tilt detection
        private const val VIBRATION_DURATION_MS = 500L
        const val GOOD_POSTURE_KEY = "goodPostureCount"
        const val BAD_POSTURE_KEY = "badPostureCount"
        const val PREFS_NAME = "PosturePrefs"
        private  val VIBRATION_PATTERN = longArrayOf(0, 200, 100, 200) // Custom vibration pattern
        private const val TAG = "PostureDetection"
        private var useMockSensor =false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        setContentView(R.layout.activity_main)

        // Initialize the TextView for posture feedback
        postureText = findViewById(R.id.postureText)
        traceStatusButton = findViewById(R.id.traceStatusButton)
        coordinatesText = findViewById(R.id.coordinatesText)
        vibrator = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
        sensorManager = getSystemService(SENSOR_SERVICE) as SensorManager
        traceStatusButton.setOnClickListener {
            val intent = Intent(this, PostureStatusActivity::class.java)
            startActivity(intent)
            }

        // Get the accelerometer sensor
        accelerometer = sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        if (accelerometer == null) {
            postureText.text = getString(R.string.error_no_accelerometer)
            Log.e(TAG, "Accelerometer not available on this device.")
        }
    }

    override fun onResume() {
        super.onResume()
        if (!useMockSensor) {
            accelerometer?.let {
                sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
            }
        } else {
            simulatePosture()
            }
    }
    private fun simulatePosture() {
        Thread {
            while (useMockSensor) {
                val (x, y, z) = mockSensor.getNextValues()  // Getting mock sensor values
                runOnUiThread {
                    detectPosture(x, y, z)  // Update the UI with detected posture
                }
                Thread.sleep(1000)  // Simulate data every second
            }
            }.start()
    }

    override fun onPause() {
        super.onPause()
        if (!useMockSensor) {
            sensorManager.unregisterListener(this)
            }
    }

    override fun onSensorChanged(event: SensorEvent) {
        if (event.sensor.type == Sensor.TYPE_ACCELEROMETER) {
            val x = event.values[0]
            val y = event.values[1]
            val z = event.values[2]

            // Log accelerometer values to ensure they are being received
            Log.d(TAG, "Accelerometer values: x=$x, y=$y, z=$z")
            coordinatesText.text = "X: ${x.toInt()} Y: ${y.toInt()} Z: ${z.toInt()}"
            detectPosture(x, y, z)
            }
    }

    private fun detectPosture(x: Float, y: Float, z: Float) {
        val sharedPreferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE)
        val editor = sharedPreferences.edit()
        // Check if the posture is bad (X or Y exceeds threshold)
        if (Math.abs(x) > POSTURE_THRESHOLD || Math.abs(y) > POSTURE_THRESHOLD) {
            postureText.text = "Bad Posture! Please straighten up."
            postureText.setTextColor(Color.RED)
            val badPostureCount = sharedPreferences.getInt(BAD_POSTURE_KEY, 0) + 1
            editor.putInt(BAD_POSTURE_KEY, badPostureCount)
            // Use a Handler to delay the vibration for 30 seconds (30000 milliseconds)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                Handler(Looper.getMainLooper()).postDelayed({

                    vibrator.vibrate(
                        VibrationEffect.createOneShot(
                            VIBRATION_DURATION_MS,
                            VibrationEffect.DEFAULT_AMPLITUDE
                        )
                    )
                }, 5000)
            }else {
                    @Suppress("DEPRECATION")
                    vibrator.vibrate(VIBRATION_DURATION_MS)
                }
            // 30000 milliseconds = 30 seconds

        } else {
            postureText.text = "Good Posture!"
            postureText.setTextColor(Color.GREEN)
            val goodPostureCount = sharedPreferences.getInt(GOOD_POSTURE_KEY, 0) + 1
            editor.putInt(GOOD_POSTURE_KEY, goodPostureCount)
            }
        editor.apply()
    }

    private fun vibrate() {
        // Vibrate when bad posture is detected
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator.vibrate(
                VibrationEffect.createWaveform(
                    VIBRATION_PATTERN,
                    -1 // Repeat pattern infinitely
                )
            )
        } else {
            @Suppress("DEPRECATION")
            vibrator.vibrate(VIBRATION_DURATION_MS)
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {
        // No action needed for this example
        }
}
class MockSensor {
    private var currentIndex = 0
    private val sampleData = listOf(
        floatArrayOf(0.5f, 0.5f, 0.0f),
        floatArrayOf(6.0f, 2.0f, 0.0f),
        floatArrayOf(2.5f, 6.0f, 0.0f),
        floatArrayOf(-6.0f, -2.5f, 0.0f),
        floatArrayOf(0.0f, 0.0f, 1.0f)
    )

    fun getNextValues(): FloatArray {
        val values = sampleData[currentIndex]
        currentIndex = (currentIndex + 1) % sampleData.size
        return values
        }
}
class PostureStatusActivity : AppCompatActivity() {

    private lateinit var goodPostureText: TextView
    private lateinit var badPostureText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_posture_status)

        goodPostureText = findViewById(R.id.goodPostureText)
        badPostureText = findViewById(R.id.badPostureText)

        // Retrieve the posture counts from SharedPreferences
        val sharedPreferences = getSharedPreferences(MainActivity.PREFS_NAME, MODE_PRIVATE)
        val goodPostureCount = sharedPreferences.getInt(MainActivity.GOOD_POSTURE_KEY, 0)
        val badPostureCount = sharedPreferences.getInt(MainActivity.BAD_POSTURE_KEY, 0)

        val totalPostureCount = goodPostureCount + badPostureCount

        // Calculate the percentages
        val goodPercentage = if (totalPostureCount > 0) (goodPostureCount * 100) / totalPostureCount else 0
        val badPercentage = if (totalPostureCount > 0) (badPostureCount * 100) / totalPostureCount else 0

        // Display the results
        goodPostureText.text = "Good Posture: $goodPercentage%"
        badPostureText.text = "Bad Posture: $badPercentage%"
        }
}